export default function Stores() {
  return <div className="p-4 text-lg font-medium">Store Finder Page</div>
}
